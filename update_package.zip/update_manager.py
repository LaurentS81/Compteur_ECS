import network
import urequests
import uos
import time
import machine
import deflate  # MicroPython supporte DEFLATE

# URLs de mise à jour sur GitHub
VERSION_FILE = "version.txt"
ZIP_FILE = "update_package.zip"

GITHUB_VERSION_URL = "https://cdn.jsdelivr.net/gh/LaurentS81/Compteur_ECS/version.txt"
GITHUB_ZIP_URL = "https://cdn.jsdelivr.net/gh/LaurentS81/Compteur_ECS/update_package.zip"

def get_current_version():
    """ Lit la version actuelle du firmware depuis version.txt """
    try:
        with open(VERSION_FILE, "r") as f:
            return f.read().strip()
    except OSError:
        return "0.0"  # Retourne 0.0 si aucun fichier version.txt n'est trouvé

def download_file(url, filename):
    """ Télécharge un fichier sans erreur de transfert chunked """
    try:
        response = urequests.get(url, stream=True)  # Activer le mode streaming
        if response.status_code == 200:
            with open(filename, "wb") as f:
                while True:
                    chunk = response.raw.read(512)  # Lire en morceaux de 512 octets
                    if not chunk:
                        break
                    f.write(chunk)
            response.close()
            print(f"✅ {filename} téléchargé avec succès !")
            return True
        else:
            print(f"❌ Erreur {response.status_code} lors du téléchargement de {filename}")
            return False
    except Exception as e:
        print(f"⚠️ Erreur de téléchargement de {filename} :", e)
        return False

def extract_zip_manually(zip_filename):
    """ Décompresse un fichier ZIP et remplace les anciens fichiers (version simplifiée) """
    try:
        with open(zip_filename, "rb") as f:
            zip_data = f.read()

        # Trouver les fichiers à l'intérieur du ZIP
        file_list = zip_data.split(b'\x50\x4B\x03\x04')  # Signature ZIP PK\x03\x04

        if len(file_list) < 2:
            print("❌ Aucun fichier valide trouvé dans le ZIP !")
            return False

        for i in range(1, len(file_list)):  # Ignorer l'en-tête du ZIP
            file_header = file_list[i]
            file_name_length = int.from_bytes(file_header[26:28], "little")
            extra_field_length = int.from_bytes(file_header[28:30], "little")

            file_name = file_header[30:30 + file_name_length].decode()
            file_data = file_header[30 + file_name_length + extra_field_length:]

            print(f"📂 Extraction de {file_name}...")

            with open(file_name, "wb") as f:
                f.write(file_data)

        print("✅ Tous les fichiers extraits avec succès !")
        return True

    except Exception as e:
        print("❌ Erreur lors de l'extraction du ZIP :", e)
        return False

def update_if_needed():
    """ Vérifie la version et applique la mise à jour si nécessaire """
    print("🔍 Vérification de la version...")

    try:
        response = urequests.get(GITHUB_VERSION_URL)
        remote_version = response.text.strip()
        response.close()

        local_version = get_current_version()

        if remote_version > local_version:
            print(f"🆕 Nouvelle version disponible ({remote_version} > {local_version})")
            if download_file(GITHUB_ZIP_URL, ZIP_FILE):
                if extract_zip_manually(ZIP_FILE):
                    with open(VERSION_FILE, "w") as f:
                        f.write(remote_version)

                    print("🔄 Redémarrage du Pico W...")
                    time.sleep(2)
                    machine.reset()
        else:
            print("✅ Déjà à jour")

    except Exception as e:
        print("⚠️ Erreur lors de la vérification de version :", e)

# Vérifier et mettre à jour si nécessaire
update_if_needed()
