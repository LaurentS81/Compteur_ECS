import update_manager  # Vérifie et applique la mise à jour avant de lancer le reste
import wifi_manager

if __name__ == '__main__':
    print("Hello World")
